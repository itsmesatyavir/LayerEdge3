export const config = {
  ref_code: "Xo6WI0EG",
  num_ref: 500, // number of references
  max_threads: 10, // số luồng
};
