const banner = ` Tool Shared By FORESTARMY: https://t.me/forestarmy`;
export default banner;
